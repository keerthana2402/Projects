import { Box, IconButton, useTheme } from "@mui/material";
import { useContext } from "react";
import { ColorModeContext, tokens } from "../../themes";
import InputBase from "@mui/material/InputBase";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import ToggleOnRoundedIcon from '@mui/icons-material/ToggleOnRounded';
//import Person2RoundedIcon from '@mui/icons-material/Person2Rounded';
import SaveRoundedIcon from '@mui/icons-material/SaveRounded';
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
//import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import SearchIcon from "@mui/icons-material/Search";
import Charts from "../../components/Charts";

const Topbar = () => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode)
    const colorMode = useContext(ColorModeContext);

    return (
    <Box display="flex" justifyContent="space-between" paddingLeft={70} paddingBottom={0}>
      <Box display="flex"  borderRadius="3px">{/* backgroundColor={colors.primary[400]} */}
        {/* <InputBase sx={{ml:2, flex:1}} placeholder="Search" /> */}
            <Charts title="ESG Central" ></Charts>
            {/* <SearchIcon /> */}
      </Box>
      <Box display="flex">
        <IconButton onClick={colorMode.toggleColorMode}>
            {theme.palette.mode === "light"? (
                <DarkModeOutlinedIcon />
            ): (
                <LightModeOutlinedIcon />
            )}    
        </IconButton>
        <IconButton >
            <ToggleOnRoundedIcon />
        </IconButton>
        <IconButton>
            <SaveRoundedIcon />
        </IconButton>
        <IconButton>
            <NotificationsOutlinedIcon />
        </IconButton>
        <IconButton>
            <PersonOutlinedIcon />
        </IconButton>
      </Box>
    </Box>
    )
}

export default Topbar;