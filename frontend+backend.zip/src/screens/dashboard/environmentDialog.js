import React from 'react';
import { useTheme } from "@mui/material";
import { useContext } from "react";
import { DataGrid } from '@mui/x-data-grid';
import { envData as data } from '../../data/envData';
import Graph from '../radial/radialGraph';
import './environmentDialog.css';
import { tokens, ColorModeContext } from "../../themes";

const columns = [
  { field: 'Year', headerName: 'YEAR', width: 200 },
  { field: 'Water_Consumption', headerName: 'WATER_CONSUMPTION', width: 200 },
  { field: 'CO2_Emissions', headerName: 'CO2_EMISSIONS', width: 200 },
  { field: 'Methane_Emissions', headerName: 'METHANE_EMISSIONS', width: 200 },
  { field: 'Nitrous_Oxide_Emissions', headerName: 'NITROUS_OXIDE_EMISSIONS', width: 200 }
];


function Content() {
  const rows = data.map((data, index) => ({ id: index, ...data }));
  const theme = useTheme();
  const colors = tokens(theme.palette.mode);
  const colorMode = useContext(ColorModeContext);

  return (
    <div className='dialogContainer'>
      <h1 className='headingTitleEnvironment'>Environment Outlook</h1>
      <div className='graphComponentEnvironment'>
        <div className='graphEnvironment'>
          <Graph value="17" label="Water Consumption" />
        </div>
        <div className='graphEnvironment'>
          <Graph value="14" label="CO2 Emissions" />
        </div>
        <div className='graphEnvironment'>
          <Graph value="8" label="Methane Emissions" />
        </div>
        <div className='graphEnvironment'>
          <Graph value="3" label="Nitrous Oxide Emissions" />
        </div>
        <div className='graphEnvironment'>
          <Graph value="10.5" label="Overall Score" />
        </div>
      </div>
      <h1 className='headingTitleEnvironment'>Time Series Criteria Breakdown</h1>
      <div style={{ height: 500, width: '100%' }}>
        <DataGrid rows={rows} columns={columns} pagesize={7} />
      </div>
      <h1 className='headingTitleEnvironment'>Industry Benchmark</h1>
      <div className='calculationEnvironment'>
        <div className='calculationTableEnvironment'>
          <h3>Water Consumption</h3>
          <h3>64</h3>
        </div>
        <div className='calculationTableEnvironment'>
          <h3>CO2 Emissions</h3>
          <h3>79</h3>
        </div>
        <div className='calculationTableEnvironment'>
          <h3>Mathane Emissions</h3>
          <h3>72</h3>
        </div>
        <div className='calculationTableEnvironment'>
          <h3>Nitrous Oxide Emissions</h3>
          <h3>56</h3>
        </div>
      </div>
    </div>
  )
}

export default Content
