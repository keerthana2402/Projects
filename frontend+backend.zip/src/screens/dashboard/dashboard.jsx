import LegendItem from '../../components/legendItem'
import { Button, IconButton, Typography, useTheme, Stack, Grid, Divider, Dialog } from "@mui/material";
import { tokens, ColorModeContext } from "../../themes";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import ToggleOnRoundedIcon from '@mui/icons-material/ToggleOnRounded';
import SaveRoundedIcon from '@mui/icons-material/SaveRounded';
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import PersonOutlinedIcon from "@mui/icons-material/PersonOutlined";
import { useContext, useState } from "react";
import { CheckBox } from "@mui/icons-material";
import BarChart from "../../components/BarCharts";
import BarChartsV from "../../components/BarChartsV";
import PieChart from "../../components/PieChart";
import PredictionDialog from '../dashboard/predictionDialog';
import EnvironmentDialog from  '../dashboard/environmentDialog'
import GovernanceDialog from './governanceDialog'
import SocialDialog from './socialDialog'
import './dashboardComponent.css'
import { useNavigate } from "react-router-dom";



const Dashboard = () => {
    const theme = useTheme();
    const colors = tokens(theme.palette.mode);
    const colorMode = useContext(ColorModeContext);
    const navigate = useNavigate()
    const[open,setOpen] = useState(false)
    const[openEnv,setOpenEnv] = useState(false);
    const[openSoc,setOpenSoc] = useState(false);
    const[openGov,setOpenGov] = useState(false);


  const [currentIndexEnv, setCurrentIndexEnv] = useState(0);
  const dataEnv = ["Water Consumption","CO2 Emissions","Methane Emissions","Nitrous Oxide Emissions"];
  const startIndexEnv = currentIndexEnv;
  const endIndexEnv = startIndexEnv + 3;
  const currentDataEnv = dataEnv.slice(startIndexEnv, endIndexEnv);

  const [currentIndexSoc, setCurrentIndexSoc] = useState(0);
  const dataSoc = ["Diversity","Work Environment","Community Impact","Diversity"];
  const startIndexSoc = currentIndexSoc;
  const endIndexSoc = startIndexSoc + 3;
  const currentDataSoc = dataSoc.slice(startIndexSoc, endIndexSoc);

  const [currentIndexGov, setCurrentIndexGov] = useState(0);
  const dataGov = ["Gender  ","Payscale   ","Leadership    ","Gender   "];
  const startIndexGov = currentIndexGov;
  const endIndexGov = startIndexGov + 3;
  const currentDataGov = dataGov.slice(startIndexGov, endIndexGov);

    return (
        <Stack className="layout" spacing={4} padding={3} margin={2} width={"100%"} backgroundColor={colors.primary[400]}>
            <div className='upload'>
                <Button onClick={() => navigate("/userlist")} variant="contained" color="primary" size="sm" alignItems="right">upload</Button>
            </div>
            {/* Header starts */}
            <Stack direction="row" justifyContent="space-between" alignItems={"center"} border={"solid 2px"}
                borderColor="black">
                <Grid display={"flex"}>
                    <Typography variant="h4" fontWeight={"bold"} color={colors.primary[600]}>ESG Central</Typography>
                </Grid>
                <Grid flex={"flex"}>                    
                    <Typography variant="h4" fontWeight={"bold"} color={colors.primary[600]}>Company Name</Typography>
                </Grid>
                <Stack width="8%" direction={"row"} justifyContent="end" alignItems={"center"}>
                        <IconButton className='iconBtns' onClick={colorMode.toggleColorMode}>
                            {theme.palette.mode === "light" ? (
                                <DarkModeOutlinedIcon />
                            ) : (
                                <LightModeOutlinedIcon />
                            )}
                        </IconButton>
                        <IconButton className='iconBtns'>
                            <ToggleOnRoundedIcon />
                        </IconButton>
                        <IconButton className='iconBtns'>
                            <SaveRoundedIcon />
                        </IconButton>
                        <IconButton className='iconBtns'>
                            <NotificationsOutlinedIcon />
                        </IconButton>
                        <IconButton className='iconBtns'>
                            <PersonOutlinedIcon />
                        </IconButton>
                </Stack>
                {/* Upload Button */}
                {/* <Stack direction={"row"} justifyContent="end" alignItems={"center"}>
                    <Button onClick={() => navigate("/userlist")} variant="contained" color="primary" size="lg">
                        Upload
                    </Button>
                </Stack> */}
            </Stack>
            {/* Header ends */}
            {/* Row 1 starts */}
            <Stack direction="row" justifyContent="space-between" minHeight={"200px"}>
                <Grid container
                    // gridcolumn="span 3"
                    border={"solid 2px"}
                    borderColor="black"
                    backgroundColor={colors.primary[400]}
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    fontSize={"18px"}
                >
                    <Stack direction="column" alignitems="center">
                        <label for="checkbox1" class="checkboxes"><input type="checkbox" id="checkbox1" name="checked" value="yes" class="checkboxes"/>CO2 Emissions</label>
                        <label for="checkbox1" class="checkboxes"><input type="checkbox" id="checkbox2" name="checked" value="yes" class="checkboxes"/>Methane Emissions</label>
                        <label for="checkbox1" class="checkboxes"><input type="checkbox" id="checkbox3" name="checked" value="yes" class="checkboxes"/>Nitrous Oxide Emissions</label>
                        <label for="checkbox1" class="checkboxes"><input type="checkbox" id="checkbox4" name="checked" value="yes" class="checkboxes"/>Water Consumption</label>
                    </Stack>
                </Grid>
                <Grid
                    container
                    border={"solid 2px"}
                    borderColor="black"
                    gridcolumn="span 2"
                    backgroundColor={colors.primary[400]}
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    fontSize={"18px"}
                    fontWeight={"bold"}
                >Industry Benchmark
                    <br /> 78%
                </Grid>
                <Grid
                    container
                    border={"solid 2px"}
                    borderColor="black"
                    gridcolumn="span 2"
                    backgroundColor={colors.primary[400]}
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    fontSize={"18px"}
                    fontWeight={"bold"}
                >ESG Score
                    <br /> 72%
                </Grid>
                <Grid container
                    border={"solid 2px"}
                    borderColor="black"
                    gridcolumn="span 2"
                    backgroundColor={colors.primary[400]}
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    fontSize={"18px"}
                    width={"100%"}
                    fontWeight={"bold"}
                >Sustainability Goal
                <section >
                    <Button className='predictionInset' variant="contained" size='md' onClick={() => setOpen(true)}>Prediction Inset</Button>
                    <Dialog maxWidth="xl" className='dialog' open={open} onClose={() => setOpen(false)}>
                        <PredictionDialog className='dialogContent' />
                    </Dialog>
                </section>
                </Grid>
                <Grid
                    container
                    border={"solid 2px"}
                    borderColor="black"
                    gridcolumn="span 3"
                    backgroundColor={colors.primary[400]}
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                    fontSize={"18px"}
                ><h5 fontSize={"18px"}>Top Focus Items</h5>
                <br/>
                    <ul>
                        <li>5 Predictions</li>
                        <li>15 Tasks</li>
                        <li>4 DEI Recommendations</li>
                        <li>Total Economic Impact</li>
                        <li>Cost: 3.6 M</li>
                        <li>Estimated Upside: 10.7 M</li>
                    </ul>
                </Grid>
            </Stack>

            {/* Row 2 Environment*/}
            <Stack direction="row" justifyContent="space-around" minHeight={"260px"} border="1px">
                <Grid gridcolumn="span 4" container className='esgGrid' border={"solid 2px"}>
                    <div direction="row">
                        <Typography variant="h4" fontWeight="bold" width="40vh" color={colors.primary[600]} style={{ cursor: 'pointer'}} onClick={() => setOpenEnv(true)}>
                            Environment
                        </Typography>
                        <Dialog maxWidth="xl" className='dialog' open={openEnv} onClose={() => setOpenEnv(false)}>
                            <EnvironmentDialog className='dialogContent' />
                        </Dialog>
                    </div>
                    
                    <div className='legend' style={{marginLeft: '60%'}}>
                        <LegendItem label="CO2 Emissions"/>
                        <LegendItem label="Water Consumption"/>
                        <LegendItem label="Methane Emissions"/>
                    </div>
                    <BarChartsV isDashboard={true} />
                </Grid>
            </Stack>
            {/* Row 3 Social */}
            <Stack direction="row" justifyContent="space-around" minHeight={"260px"}>
                <Grid gridcolumn="span 4" container className='esgGrid' border={"solid 2px"}>
                    <div direction="row">
                    <Typography variant="h4" fontWeight="bold" width="40vh" color={colors.primary[600]} style={{ cursor: 'pointer'}} onClick={() => setOpenSoc(true)}>
                        Social
                    </Typography>
                    <Dialog maxWidth="xl" className='dialog' open={openSoc} onClose={() => setOpenSoc(false)}>
                        <SocialDialog className='dialogContent'/>
                    </Dialog>
                    </div>
                    <div className='legend' style={{marginLeft: '60%'}}>
                        <LegendItem label="Diversity"/>
                        <LegendItem label="Work Environment"/>
                        <LegendItem label="Community Impact"/>
                    </div>
                    <PieChart />
                </Grid>
            </Stack>
            {/* Row 4  Governance*/}
            <Stack direction="row" justifyContent="space-around" minHeight={"260px"}>
                <Grid gridcolumn="span 4" container className='esgGrid' border={"solid 2px"}>
                    <div>
                    <Typography variant="h4" fontWeight="bold" width="40vh" color={colors.primary[600]} style={{ cursor: 'pointer'}} onClick={() => setOpenGov(true)}>
                        Governance
                    </Typography>
                    <Dialog maxWidth="xl" className='dialog' open={openGov} onClose={() => setOpenGov(false)}>
                        <GovernanceDialog className='dialogContent'/>
                    </Dialog>
                    </div>
                    <div className='legend' style={{marginLeft: '60%'}}>
                        <LegendItem label="Gender"/>
                        <LegendItem label="Payscale"/>
                        <LegendItem label="Leadership"/>
                    </div>
                    <BarChart isDashboard={true} />
                </Grid>
            </Stack>

            {/* Row 5 KPI */}
            <Stack direction="row" justifyContent="space-between" backgroundColor={colors.primary[400]} >
                <Grid container
                    border={"solid 2px"}
                    borderColor="black">
                    <Typography variant="h4" fontWeight="bold" color={colors.primary[600]}>KPI Selection</Typography>
                </Grid>
            </Stack>
            {/* Row 6 Footer */}
            <Stack direction="row" justifyContent="space-between" minHeight={"160px"}>
                <Grid gridcolumn="span 4" container border={"solid 2px"} maxWidth={"470px"} borderColor="black" gridRow="span 1" backgroundColor={colors.primary[400]} >
                    <Stack direction="row" width={"90%"} justifyContent={"space-between"} >
                        <Button className='buttonGrid' width="25px" onClick={() => setCurrentIndexEnv(currentIndexEnv - 1)} disabled={currentIndexEnv === 0}>{'<'}</Button>
                        <Divider orientation="vertical" />
                        {currentDataEnv.map((element, index) => (
                            <Grid item key={index} xs={3}>
                                <Stack justifyContent={"center"} alignItems={"center"} margin={1}>
                                    <Typography variant="body" fontSize={"15px"} align="center" fontWeight="600">
                                        <label for="checkbox5" class="checkboxes"><input type="checkbox" id="checkbox5" name="checked" value="yes" class="checkboxes" />{element}</label>
                                    </Typography>
                                </Stack>
                            </Grid>
                        ))}
                        <Divider orientation="vertical" />
                        <Button className='buttonGrid' width="20px" direction="right" onClick={() => setCurrentIndexEnv(currentIndexEnv + 1)} disabled={endIndexEnv >= dataEnv.length}>{'>'}</Button>
                    </Stack>
                </Grid>
                <Grid gridcolumn="span 4" container border={"solid 2px"} maxWidth={"470px"} borderColor="black" gridRow="span 1" backgroundColor={colors.primary[400]} >
                    <Stack direction="row" width={"90%"} justifyContent={"space-between"}>
                        <Button className='buttonGrid' width="25px" onClick={() => setCurrentIndexSoc(currentIndexSoc - 1)} disabled={currentIndexSoc === 0}>{'<'}</Button>
                        <Divider orientation="vertical" />
                        {currentDataSoc.map((element, index) => (
                            <Grid item key={index} xs={3}>
                                <Stack justifyContent={"center"} alignItems={"center"} margin={1}>
                                    <Typography variant="body" fontSize={"15px"} align="center" fontWeight="600">
                                        <label for="checkbox6" class="checkboxes"><input type="checkbox" id="checkbox6" name="checked" value="yes" class="checkboxes" />{element}</label>
                                    </Typography>
                                </Stack>
                            </Grid>
                        ))}
                        <Divider orientation="vertical" />
                        <Button className='buttonGrid' direction="right" onClick={() => setCurrentIndexSoc(currentIndexSoc + 1)} disabled={endIndexSoc >= dataSoc.length}>{'>'}</Button>
                    </Stack>
                </Grid>
                <Grid gridcolumn="span 4" container border={"solid 2px"} maxWidth={"450px"} borderColor="black" gridRow="span 1" backgroundColor={colors.primary[400]} >
                    <Stack direction="row" width={"90%"} justifyContent={"sspace-between"}>
                        <Button className='buttonGrid' width="25px" onClick={() => setCurrentIndexGov(currentIndexGov - 1)} disabled={currentIndexGov === 0}>{'<'}</Button>
                        <Divider orientation="vertical" />
                        {currentDataGov.map((element, index) => (
                            <Grid item key={index} xs={3}>
                                <Stack justifyContent={"center"} alignItems={"center"} margin={1}>
                                    <Typography variant="body" fontSize={"15px"} align="center" fontWeight="600">
                                        <label for="checkbox7" class="checkboxes"><input type="checkbox" id="checkbox7" name="checked" value="yes" class="checkboxes" />{element}</label>
                                    </Typography>
                                </Stack>
                            </Grid>
                        ))}
                        <Divider orientation="vertical" />
                        <Button className='buttonGrid' direction="right" onClick={() => setCurrentIndexGov(currentIndexGov + 1)} disabled={endIndexGov >= dataGov.length}>{'>'}</Button>
                    </Stack>
                </Grid>
            </Stack>
            {/* Last Footer */}
            <Stack direction="row" justifyContent="space-between" backgroundColor={colors.primary[400]}>
                <Grid container
                    border={"solid 2px"}
                    borderColor="black">
                    <Typography variant="subtitle" fontWeight="bold" color={colors.primary[600]}>copyright registered </Typography>
                </Grid>
            </Stack>
        </Stack>
    );
}

export default Dashboard;