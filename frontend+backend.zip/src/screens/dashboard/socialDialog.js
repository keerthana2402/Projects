import React from 'react'
import { DataGrid } from '@mui/x-data-grid';
import {envData as data} from '../../data/envData'
import './socialDialog.css'
import Graph from '../radial/radialGraph'


const columns = [
  { field: 'Year', headerName: 'YEAR', width: 100 },
  { field: 'Water_Consumption', headerName: 'WATER_CONSUMPTION', width: 200 },
  { field: 'CO2_Emissions', headerName: 'CO2_EMISSIONS', width: 100 },
  { field: 'Methane_Emissions', headerName: 'METHANE_EMISSIONS', width: 100 },
  { field: 'Nitrous_Oxide_Emissions', headerName: 'NITROUS_OXIDE_EMISSIONS', width: 100 },
];

function Content() {
  const rows = data.map((data, index) => ({ id: index, ...data }));

  return (
    <div className='dialogContainer'>
        <h3 className='headingTitle'>Social Outlook</h3>
          <div className='graphComponent'>
            <div className='graph'>
              <Graph />
              <h3>Overall Score</h3>
            </div>
            <div className='graph'>
              <Graph />
              <h3>Free Risk Score</h3>
            </div>
            <div className='graph'>
              <Graph />
              <h3>Water Stress Score</h3>
            </div>
          </div>
        <h3 className='headingTitle'>Time Series Criteria Breakdown</h3>
          <div style={{ height: 400, width: '100%' }}>
            <DataGrid rows={rows} columns={columns} pagesize={10} />
          </div>

        <h3 className='headingTitle'>Industry Benchmark</h3>
          <div className='calculation'>
            <div className='calculationTable'>
              <h3>CO2 Emissions</h3>
              <h3>20.2</h3>
            </div>
            <div className='calculationTable'>
              <h3>Water Consumption</h3>
              <h3>18.2</h3>
            </div>
            <div className='calculationTable'>
              <h3>Mathane Emissions</h3>
              <h3>19.7</h3>
            </div>
          </div>
    </div>
  )
}

export default Content
