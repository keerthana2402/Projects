import React from 'react'
import { DataGrid } from '@mui/x-data-grid';
import { hrData as data } from '../../data/hrData'
import './governanceDialog.css'
import Graph from '../radial/radialGraph'


const columns = [
  { field: 'Year', headerName: 'YEAR', width: 200 },
  { field: 'Gender', headerName: 'GENDER', width: 200 },
  { field: 'Leadership_Feedback', headerName: 'LEADERSHIP_FEEDBACK', width: 200 },
  { field: 'Payscale_Range', headerName: 'PAYSCALE_RANGE', width: 200 },
];

function Content() {
  const rows = data.map((data, index) => ({ id: index, ...data }));

  return (
    <div className='dialogContainer'>
      <h1 className='headingTitleGovernance'>Governance Outlook</h1>
      <div className='graphComponentGovernance'>
        <div className='graphGovernance'>
          <Graph value="71" label="Gender" />
        </div>
        <div className='graphGovernance'>
          <Graph value="86" label="Payscale" />
        </div>
        <div className='graphGovernance'>
          <Graph value="50" label="Leadership" />
        </div>
        <div className='graphGovernance'>
          <Graph value="70" label="Overall Score" />
        </div>
      </div>
      <h1 className='headingTitleGovernance'>Time Series Criteria Breakdown</h1>
      <div style={{ height: 500, width: '100%' }}>
        <DataGrid rows={rows} columns={columns} pagesize={7} />
      </div>
      <h1 className='headingTitleGovernance'>Industry Benchmark</h1>
      <div className='calculationGovernance'>
        <div className='calculationTableGovernance'>
          <h3>Gender</h3>
          <h3>74</h3>
        </div>
        <div className='calculationTableGovernance'>
          <h3>Payscale</h3>
          <h3>70</h3>
        </div>
        <div className='calculationTableGovernance'>
          <h3>Leadership</h3>
          <h3>91</h3>
        </div>
      </div>
    </div>
  )
}

export default Content
