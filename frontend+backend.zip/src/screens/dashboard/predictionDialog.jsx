import React, { useState } from 'react';
import './predictionDialog.css';
//import ResultCard from './resultCard';

function PredictionDialog() {
    const [envPercentage, setValue1] = useState(50);
    const [socPercentage, setValue2] = useState(40);
    const [govPercentage, setValue3] = useState(30);
    const outcomeValue = Math.round((Number(envPercentage) + Number(socPercentage) + Number(govPercentage)) / 3);
    const [envTasks] = useState(15);
    const [socTasks] = useState(5);
    const [govTasks] = useState(10);


    const handleSliderChange1 = (event) => {
        setValue1(event.target.value);
    }

    const handleSliderChange2 = (event) => {
        setValue2(event.target.value);
    }

    const handleSliderChange3 = (event) => {
        setValue3(event.target.value);
    }

    return (
        <div className='page'>
            <h1 className='titleHeading'>Prediction Inset</h1>

            <div className='pageContent'>
                <div className='heading'>
                    <h1 className='titleHead' color='#'>Predictions and Recommendations</h1>
                </div>

                <div className='cards'>
                    {/*  <ResultCard /> */}
                    <div className='display'>
                        <div className='outcomeBenchmark'>
                            <div className='outcome'>
                                <h1>Outcome</h1>
                                <h2>{outcomeValue}%</h2>
                            </div>
                            <div className='benchmark'>
                                <h1>Benchmark</h1>
                                <h2>90%</h2>
                            </div>
                        </div>
                        <div className='resultRecommendation'>
                            <div className='containerResultCard'>
                                <h1>Results</h1>
                                <div className='environment'>
                                    <h3>Environment</h3>
                                    <div className='environmentSlider'>
                                        <h3 className='contentPercentage'>{envPercentage}%</h3>
                                        <input
                                            className='sliderBar'
                                            type="range"
                                            min="0"
                                            max="100"
                                            value={envPercentage}
                                            onChange={handleSliderChange1}
                                        />
                                    </div>
                                </div>
                                <div className='social'>
                                    <h3>Social</h3>
                                    <div className='socialSlider'>
                                        <h3 className='contentPercentage'>{socPercentage}%</h3>
                                        <input
                                            className='sliderBar'
                                            type="range"
                                            min="0"
                                            max="100"
                                            value={socPercentage}
                                            onChange={handleSliderChange2}
                                        />
                                    </div>
                                </div>
                                <div className='governance'>
                                    <h3>Governance</h3>
                                    <div className='governanceSlider'>
                                        <h3 className='contentPercentage'>{govPercentage}%</h3>
                                        <input
                                            className='sliderBar'
                                            type="range"
                                            min="0"
                                            max="100"
                                            value={govPercentage}
                                            onChange={handleSliderChange3}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div className='recommendationCard'>

                                <h1>Recommendations</h1>

                                <div className='environment'>
                                    <h3>Environment</h3>
                                    <div>
                                    <h3>{envPercentage<=50 ? envTasks : Math.round(40-(100-(envPercentage))/2)} tasks</h3>
                                    </div>
                                </div>
                                <div className='social'>
                                    <h3>Social</h3>
                                    <div>
                                    <h3>{socPercentage<=40 ? socTasks : Math.round(25-(100-(socPercentage))/3)} tasks</h3>
                                    </div>
                                </div>
                                <div className='governance'>
                                    <h3>Governance</h3>
                                    <div>
                                    <h3>{govPercentage<=30 ? govTasks : Math.round(45-(100-(govPercentage))/2)} tasks</h3>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='economicImpactCard'>
                            <div className='abc'>
                                <h1>Economic Impact</h1>
                                <div className='economicImpactValues'>
                                    <div className='economicImpactCardContent'>
                                        <h3>Cost</h3>
                                        <p>{(outcomeValue / 10).toFixed(2)} M</p>
                                    </div>
                                    <div className='economicImpactCardContent'>
                                        <h3>Upside</h3>
                                        <p>{((outcomeValue / 10) - 2).toFixed(2)} M</p>
                                    </div>
                                    <div className='economicImpactCardContent'>
                                        <h3>Positive</h3>
                                        <p>{((outcomeValue / 10) + 2).toFixed(2)} M</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default PredictionDialog;