import React from 'react';
import Gauge from 'react-svg-gauge';

class RadialGauge extends React.Component {
  render() {
    return (
      <div>
        <Gauge value={this.props.value} min={0} max={100} width={200} height={160} label={this.props.label}/>
      </div>
    );
  }
}

export default RadialGauge;
