import React, { useState, useEffect } from "react";
import axios from "axios";
import Button from "react-bootstrap/Button";
import "./index.css";
import { Stack } from "@mui/material";


const UserList = () => {
  const [file, setFile] = useState(null);
  const [folder, setFolder] = useState("");
  const [mapping_name, setMappingName] = useState([]);
  const [selectedMapping, setSelectedMapping] = useState(null);
  const API_ENDPOINT = "https://pxme3u89x9.execute-api.us-east-1.amazonaws.com/S3presignedURL";

  const getMappings = async () => {
    const res = await fetch("filemapping");
    const data = await res.json();
    //console.log("data", data);
    setMappingName(data);
  }

  useEffect(() => {
    getMappings()
  }, []);

  const onFolderChange = (event) => {
    setFolder(event.target.value)
    console.log("selected folder", event.target.value)
  }
  const onMappingChange = (event) => {
    console.log("Mapping_name_id", event.target.value)
    setSelectedMapping(event.target.value);
    event.preventDefault();
  }

  const onSave = async () => {

    // get presigned url
    const url = await axios.get(API_ENDPOINT, {
      headers: {
        filename: `${folder}/${file.name}`,
      },
    })
    .then(res => res.data)
    .catch((e) => console.log("failed to get presigned url", e))
    console.log("upload url", url)

    // upload file
    axios.put(url.uploadURL, file, {
      headers: {
        ContentType: "multipart/form-data",
      },
    }).then((res) => {
      console.log("File Uploaded!",res)
      //alert("File Uploaded Successfully!")
    }).catch((e) => console.log("Upload file failed", e))

  };

  return (
    <Stack className="outerContainer">
      <div className="flex-space-between header-bar text-center">
        <h4 >Data Upload UI</h4>
      </div>

      <table className="tablestyles" cellPadding="25" cellSpacing="20">
        <tbody>
          <tr>
            <td>
              <label className="data">DataType</label>
            </td>
            <td>
              <select id="dropdown" onChange={(e) => onFolderChange(e)}>
                <option defaultValue="ENVIRONMENT">ENVIRONMENT</option>
                <option defaultValue="SOCIAL">SOCIAL</option>
                <option defaultValue="GOVERNANCE">GOVERNANCE</option>
              </select>
            </td>
          </tr>
          <tr>
            <td>
              <label className="data">File Path</label>
            </td>
            <td>
              <input
                id="outlined-basic"
                name="file"
                label="Outlined"
                variant="outlined"
                type="file"
                accept="*.*"
                multiple={false}
                onChange={(e) => setFile(e.target.files[0])}
              />
            </td>
          </tr>
          <tr>
            <td>
              <label className="data">Choose File Mapping </label>
            </td>
            <td>
              <select className="form-control" onChange={(e) => onMappingChange(e)}>
                <option defaultValue="selected">--Select File Mapping--</option>
                {
                  mapping_name.map((getName) => (
                    <option selected={selectedMapping === getName._id ? "selected" : null} key={getName._id}>{getName.file_mapping_name}</option>
                  ))
                }
              </select>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>
              <Button
                variant="contained"
                color="primary"
                size="lg"
                className="button_save"
                onClick={onSave}>
                Save
              </Button>
            </td>
          </tr>
        </tfoot>
      </table>
    </Stack>
  );
};
export default UserList;