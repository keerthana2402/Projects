import { Box } from "@mui/material";
import BarChart from "../../components/BarCharts";

const Bar = () => {
  return (
    <Box m="20px">
      {/* <Header title="Bar Chart" subtitle="Simple Bar Chart" /> */}
      <Box maxHeight="40px">{/* height="10vh" */}
        <BarChart />
      </Box>
    </Box>
  );
};

export default Bar;