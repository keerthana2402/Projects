import React from 'react';


const LegendItem = ({ label, isChecked, handleChange }) => (
  <div>
    <label>
      <input type="checkbox" checked={isChecked} onChange={handleChange} />
      <span>{label}</span>
    </label>
  </div>
);

export default LegendItem;
